David Liu
CSS 390 - Scripting - Assignment #3
Autumn, 2020 - 11/11/2020


This homework assignment shows the log analysis from data collected from: https://courses.washington.edu/css390/scripting/2020-q4/assignment-03.html
Following the stylistic expected output of given file report.txt, this homework assignment displays a solution of how to read cookies and segments
in python to derive any meaningful output. 

Output is derived in the form of:
Segments that gained extra cookies
Segments that lost cookies
Cookies assigned to extra segments
Cookies omitted from segments

I have created 2 smaller datasets named: "small-baseline.txt" and "small-evaluate.txt" to test my solution against a smaller sample size.
output2.txt records the reports scripts output.

Note that in the future, using Pickle for larger datasets in the testing phase would've been useful given a python solution.