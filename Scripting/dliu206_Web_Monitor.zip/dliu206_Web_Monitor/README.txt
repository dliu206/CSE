David Liu
CSS 390 - Scripting

Assignment 4: Website Monitoring

Using the given website time server given by timeserver.py and trafficstats.py, I developed trafficgen.py that creates traffic for the given time server.

trafficgen.py takes 3 arguments which runs alongside timeserver.py:
--url url: request URL
--rps rps: desired average requests per second
--jitter jitter: floating-point number in the range of [0..1] representing the shakiness of the rate. The actual request rate should vary randomly between rps * (1.0 - jitter) and rps * (1.0 + jitter).

Traffic Gen is capable of creating intermittent behavior by using time.sleep() randomly as well as cyclical behavior by following a pre-defined loop.

collector.py that reads the response from host:port/stats. 
That periodically collects data from the stats page and saves it in a tab-separated file, where each record contains the Unix time (seconds since 1970) the collection was made and the count of 200s, 404s, and 500s.
Uses a command-line flag --interval to control the collection interval. 
Run the script for an hour against your the web site being fed traffic, sampling data every 10 seconds on default.

The output created by collector.py is named output.tsv

plot.py that takes the data collected by collector and generates the 1-minute rate graph of the 3 time-series.
The graph was generated using gnuplot or Python's matplotlib.


Notes:
Revised timeserver.py to work with Python 3.7