from matplotlib import pyplot as plt
import csv

time = []
success = []
error = []
fail = []

index = 0
with open("output_intermittent.tsv", newline='') as f:
    r = csv.reader(f)
    for line in r:
        if index > 0:
            line = line[0].split('\t')
            time.append(line[0])
            success.append(line[1])
            error.append(line[2])
            fail.append(line[3])
        index += 1

if len(time) > 2:
    deltaTime = int(time[len(time) - 1]) - int(time[len(time) - 2])
else:
    deltaTime = 0

n = int(60 / deltaTime)

newTime = []
newSuccess = []
newError = []
newFail = []

for index in range(1, int(len(time) / n)):
    newTime.append(index)
    print(index)
    newSuccess.append(int(success[n * index]) - int(success[n * (index - 1)]))
    newError.append(int(error[n * index]) - int(error[n * (index - 1)]))
    newFail.append(int(fail[n * index]) - int(fail[n * (index - 1)]))

plt.plot(newTime, newSuccess, 'rs-', label='200s', linewidth=2)
plt.plot(newTime, newError, 'go-', label='404s', linewidth=2)
plt.plot(newTime, newFail, 'bo-', label='500s', linewidth=2)
plt.autoscale()
plt.title("RPS over Time")
plt.ylabel("RPS (1-minute rate)")
plt.xlabel("Time (Minutes)")
plt.legend(loc='best')
plt.show()
