from http.server import BaseHTTPRequestHandler, HTTPServer
import argparse
import datetime
import http.client as httplib
import sys
import time

import trafficstats

__copyright__ = 'Copyright 2014 Systems Deployment, LLC'
__author__ = 'Morris Bernstein'
__email__ = 'morris@systems-deployment.com'


DEFAULT_PORT = 8080

time_page = """
<html>
<head>
<title>CSS 390 Time Server</title>
</head>
<body>
<p>
Current time: {}
</p>
</body>
</html>
"""


def run(stats, port=DEFAULT_PORT):
    class Handler(BaseHTTPRequestHandler):
        def do_GET(self):
            {'/': self.do_time,
             '/fail': self.do_fail,
             '/stats': self.do_stats}.get(self.path, self.do_404)()
        def do_404(self):
            stats.increment('404s')
            self.send_error(httplib.NOT_FOUND, "Not found: {}".format(self.path))
        def do_fail(self):
            stats.increment('500s')
            self.send_error(httplib.INTERNAL_SERVER_ERROR, 'Internal error: {}'.format(self.path))
        def do_stats(self):
            self.send_response(httplib.OK)
            self.send_header('content-type', 'text/plain')
            self.end_headers()
            now = int(time.time())
            print('stats: time', now)
            self.wfile.write(bytes('time: {}\n'.format(now), encoding='utf8'))
            for k, v in stats.stats.items():
                print('stats: ', k, v)
                self.wfile.write(bytes('{}: {}\n'.format(k, int(v)), encoding='utf8'))
        def do_time(self):
            stats.increment('200s')
            self.send_response(httplib.OK)
            self.send_header('content-type', 'text/html; charset=utf-8')
            self.end_headers()
            self.wfile.write(bytes(time_page.format(datetime.datetime.today().ctime()), encoding='utf8'))

    server_address = ('', port)
    server = HTTPServer(server_address, Handler)
    sys.stderr.write('started server on port {}\n'. format(port))
    server.serve_forever()


if __name__ == '__main__':
    parser = argparse.ArgumentParser()
    parser.add_argument('--port',
                        dest='port',
                        type=int,
                        default=DEFAULT_PORT)
    args = parser.parse_args()

    stats = trafficstats.Stats()
    run(stats, port=args.port)

