import sys
import random
from urllib.request import urlopen
from urllib.error import HTTPError, URLError
from urllib.parse import quote
from time import sleep
from timeserver import DEFAULT_PORT


# Trigger Cyclical Behavior
# If False, triggers intermittent behavior
cyclicalBehavior = True

try:
    url = str(sys.argv[1])
    rps = int(sys.argv[2])
    jitter = float(sys.argv[3])
    run = True
except IndexError:
    print("Not enough arguments.")
    print("--url url: request URL\n"
          "--rps rps: desired average requests per second\n"
          "--jitter jitter: floating-point number in the range of [0..1] representing the shakiness of the rate. "
          "The actual request rate should vary randomly between rps * (1.0 - jitter) and rps * (1.0 + jitter).")
    url = ""
    rps = 0
    jitter = 0
    run = False


if jitter < 0:
    jitter = 0
elif jitter > 1:
    jitter = 1

url = url + quote(":") + str(DEFAULT_PORT)

upperRequestRate = rps * (1.0 + jitter)
lowerRequestRate = rps * (1.0 - jitter)



while run:
    requestRate = random.randint(lowerRequestRate, upperRequestRate)
    for request in range(requestRate):
        if not cyclicalBehavior:
            # Random Value == 0 == Pass (200)
            # Random Value == 1 == Not Found (404)
            # Random Value == 2 == Fail (500)
            randomValue = random.randint(0, 2)
            randomValue2 = random.randint(0, 9)
            try:
                if randomValue == 0:
                    urlopen(url)
                elif randomValue == 1:
                    urlopen(url + "/kappa")
                else:
                    urlopen(url + "/fail")
            except HTTPError:
                continue
            except URLError:
                break

            # Intermittent Behavior
            if randomValue2 == 0:
                sleep(1)

        else:
            try:
                if request % 4 == 0:
                    urlopen(url)
                elif request % 4 == 1 or request % 4 == 2:
                    urlopen(url + "/kappa")
                else:
                    urlopen(url + "/fail")
            except HTTPError:
                continue
            except URLError:
                break


