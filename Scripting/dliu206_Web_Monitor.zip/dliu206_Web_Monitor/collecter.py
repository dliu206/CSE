import sys
import csv
import time
from urllib.request import urlopen
from urllib.parse import quote

interval = 1

try:
    flag = sys.argv[1]
    num = float(sys.argv[2])
except IndexError:
    flag = ""
    num = 0


if flag == "--interval":
    interval = num

stats = "http://127.0.0.1" + quote(":") + "8080" + "/stats"


with open('output.tsv', 'w', newline='') as f:
    fileWriter = csv.writer(f, delimiter="\t")
    fileWriter.writerow(['time'.ljust(10), '200s', '404s', '500s'])
    start = time.time()
    while time.time() - start < 100:
        httpResponse = urlopen(stats).read().decode('utf-8').split('\n')
        httpResponse.remove('')
        for element in range(len(httpResponse)):
            httpResponse[element] = httpResponse[element][httpResponse[element].find(" ") + 1:]
        fileWriter.writerow(httpResponse)
        time.sleep(interval)


