#include <stdio.h>

#include "bfs.h"
#include "errors.h"
#include "p5test.h"

int main() {
    bfsInitOFT();
    p5test();
    return 0;
}